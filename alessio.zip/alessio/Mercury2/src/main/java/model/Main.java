package model;

import java.time.LocalDate;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Utilities.connessione();

Zona z = new Zona(2,113,7905);
LocalDate day = LocalDate.of(2020, 10, 10);
UtenteRegistrato u = new UtenteRegistrato("ciao",z, "fiera", "mensile", day);
NewsLetter newsss = Utilities.news(u);
System.out.println(newsss.getEventi().get(0));


	}

}