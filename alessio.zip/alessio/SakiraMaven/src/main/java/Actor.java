

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table( name = "actor" )
public class Actor {

	private int actor_id;
	private String nome;
	private String cognome;
	private Date ultimoAggiornamento;
	
	public Actor() {

	}

	public Actor(String nome, String cognome, Date ultimoAggiornamento) {
		this.nome = nome;
		this.cognome = cognome;
		this.ultimoAggiornamento = ultimoAggiornamento;
	}
	
	@Id
	@GeneratedValue(generator="increment")
	@GenericGenerator(name="increment", strategy = "increment")
    public int getActor_id() {
		return actor_id;
    }
	
    private void setActor_id(int actor_id) {
		this.actor_id = actor_id;
    }
    
	@Column(name = "last_name")
	public String getCognome() {
		return cognome;
	}
	@Column(name = "last_name")
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	
	@Column(name = "first_name")
	public String getNome() {
		return nome;
	}
	@Column(name = "first_name")
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "last_update")
    public Date getUltimoAggiornamento() {
		return ultimoAggiornamento;
    }
	
	@Column(name = "last_update")
	public void setUltimoAggiornamento(Date ultimoAggiornamento) {
		this.ultimoAggiornamento = ultimoAggiornamento;
	}
	
	
	
	
}
