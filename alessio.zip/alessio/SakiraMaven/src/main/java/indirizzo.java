
public class indirizzo {

}
