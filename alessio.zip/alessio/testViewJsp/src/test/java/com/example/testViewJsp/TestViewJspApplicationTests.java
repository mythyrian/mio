package com.example.testViewJsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestViewJspApplicationTests {

	@Test
	void contextLoads() {
	}

}
